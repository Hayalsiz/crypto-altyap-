  
const Discord = require('discord.js');
module.exports = {
    name: '',
    aliases: [],
    category: 'bot',

    run: (client, message, args) => {
            let tik = client.guilds.cache.get("714204056092147824").emojis.cache.find(emoji => emoji.name === 'tik');
      let no = client.guilds.cache.get("714204056092147824").emojis.cache.find(emoji => emoji.name === 'cross');
}
};